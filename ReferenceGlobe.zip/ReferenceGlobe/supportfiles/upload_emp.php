<?php
$db = mysqli_connect("localhost", "root", "","rgemployee") or die("Could not connect123.");

     
//echo $yearid; exit;
 

$handle = fopen("empupload.csv", "r");
while (($data = fgetcsv($handle, 1000000, ",")) !== FALSE)
{

 $import = "insert into employee_info (emp_name,designation,dob,doj,blood_group,mobile,email,address) values ('".$data[0]."','".$data[1]."','".$data[2]."','".$data[3]."','".$data[4]."','".$data[5]."','".$data[6]."','".$data[7]."')";

  mysqli_query($db,$import) or die("mysql_error()");

}
echo "completed";

?>