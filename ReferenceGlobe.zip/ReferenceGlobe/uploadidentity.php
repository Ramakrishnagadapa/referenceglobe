<?php session_start();  if(!isset($_SESSION['emp_id'])) { echo "<script>"; echo "location.href='../index.php'"; echo "</script>"; }?>
<!doctype html>

<html class="no-js" lang="en">

<?php include "include/head.php";?>
<?php include "include/left_panel.php";?>
<style>
body {font-family: calibri;}
.bgColor {
    max-width: 440px;
    height: 400px;
    background-color: #c3e8cb;
    padding: 30px;
    border-radius: 4px;
	text-align: center;    
}
#targetOuter{	
	position:relative;
    text-align: center;
    background-color: #F0E8E0;
    margin: 20px auto;
    width: 200px;
    height: 200px;
	border-radius: 4px;
}
.btnSubmit {
    background-color: #565656;
    border-radius: 4px;
    padding: 10px;
    border: #333 1px solid;
    color: #FFFFFF;
    width: 200px;
	cursor:pointer;
}
.inputFile {
    padding: 5px 0px;
	margin-top:8px;	
    background-color: #FFFFFF;
    width: 48px;	
    overflow: hidden;
	opacity: 0;	
	cursor:pointer;
}
.icon-choose-image {
    position: absolute;
    opacity: 0.1;
    top: 50%;
    left: 50%;
    margin-top: -24px;
    margin-left: -24px;
    width: 48px;
    height: 48px;
}
.upload-preview {border-radius:4px;}
#body-overlay {background-color: rgba(0, 0, 0, 0.6);z-index: 999;position: absolute;left: 0;top: 0;width: 100%;height: 100%;display: none;}
#body-overlay div {position:absolute;left:50%;top:50%;margin-top:-32px;margin-left:-32px;}

</style>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript">
function showPreview(objFileInput) {
    if (objFileInput.files[0]) {
        var fileReader = new FileReader();
        fileReader.onload = function (e) {
            $("#targetLayer").html('<img src="'+e.target.result+'" width="200px" height="200px" class="upload-preview" />');
			$("#targetLayer").css('opacity','0.7');
			$(".icon-choose-image").css('opacity','0.5');
        }
		fileReader.readAsDataURL(objFileInput.files[0]);
    }
}


function showPreview2(objFileInput) {
    if (objFileInput.files[0]) {
        var fileReader = new FileReader();
        fileReader.onload = function (e) {
            $("#targetLayer2").html('<img src="'+e.target.result+'" width="200px" height="200px" class="upload-preview2" />');
			$("#targetLayer2").css('opacity','0.7');
			$(".icon-choose-image2").css('opacity','0.5');
        }
		fileReader.readAsDataURL(objFileInput.files[0]);
    }
}
</script>

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include "include/header_top.php";?>
		<!-- /header -->
        <!-- Header-->

 <div class="content mt-3">
            <div class="animated fadeIn">
				
<?php if( $_GET['action']=='edit' ){

 if($_POST['submit'] == "edit"){
extract($_POST);
		
date_default_timezone_set('Asia/Kolkata');
$todate = date('Y-m-d');

if($_FILES["aadharphoto"]["name"]!=''){		
$target_path = "uploads/aadhar/";
$extension = pathinfo($_FILES["aadharphoto"]["name"], PATHINFO_EXTENSION);
$newfilename=$_SESSION['emp_id'].".".$extension;
$president_photo = $target_path.$newfilename;
move_uploaded_file($_FILES['aadharphoto']['tmp_name'], $president_photo);

$job_image = $newfilename;	

$mydb->qry("update   usermaster set aadhar='$job_image' where id=".$_SESSION['emp_id']."");

}

if($_FILES["panpic"]["name"]!=''){		
$target_path = "uploads/pan/";
$extension = pathinfo($_FILES["panpic"]["name"], PATHINFO_EXTENSION);
$newfilename=$_SESSION['emp_id'].".".$extension;
$president_photo = $target_path.$newfilename;
move_uploaded_file($_FILES['panpic']['tmp_name'], $president_photo);

$job_image = $newfilename;	

$mydb->qry("update   usermaster set pan='$job_image' where id=".$_SESSION['emp_id']."");
}


					
						
						 
						echo "<script>";
						 echo "location.href='uploadidentity.php'";
						echo "</script>";
						}
						
						$getdata = $mydb->qry("select * from   usermaster where id=".$_SESSION['emp_id']);
						
				
					
?>		 
        <div class="col-lg-12">
		<form  method="post"  action="" enctype="multipart/form-data" name="form1">
		<input type="hidden" name="MAX_FILE_SIZE" value="300000000000" />
                                                <div class="card">
                                                    <div class="card-header">
                                                        <strong>Edit My Files</strong>
                                                    </div>
                                                    <div class="card-body card-block">
													
         <div id="body-overlay"><div><img src="assets/img/loading.gif" width="64px" height="64px"/></div></div>                                                   
														
															<div class="row form-group">
                                                                <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Aadhar Card</label></div>
                                                                <div class="col-12 col-md-9">
																
																<div id="targetOuter">
	<div id="targetLayer"></div>
	<img src="assets/img/photo.png"  class="icon-choose-image" />
	<div class="icon-choose-image" >
	<input name="aadharphoto" id="aadharphoto" type="file" class="inputFile" onChange="showPreview(this);" />
	</div>
</div>
																</div>
                                                            </div>
															<div class="row form-group">
                                                                <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Pan Card</label></div>
                                                                <div class="col-12 col-md-9">
																
																<div id="targetOuter">
	<div id="targetLayer2"></div>
	<img src="assets/img/photo.png"  class="icon-choose-image" />
	<div class="icon-choose-image" >
	<input name="panpic" id="panpic" type="file" class="inputFile" onChange="showPreview2(this);" />
	</div>
</div>
																</div>
                                                            </div>
                                                       
                                                    </div>
                                                    <div class="card-footer">
                                                        <button type="submit" name="submit" value="edit" class="btn btn-primary btn-sm float-right">
                                                            <i class="fa fa-dot-circle-o"></i> Update
                                                        </button>
                                                        
                                                    </div>
                                                </div>
                                                
                                                
                   </form>                             
                                            </div> <!-- .content -->
											
<?php }else{?>											
<div class="col-lg-12">
                        <div class="card">
                            <div class="page-header float-left">
								<div class="page-title">
									<h1>My Profile
									<a href="uploadidentity.php?action=edit"><button style="float:right" type="button" class="btn btn-success"><i class="fa fa-edit"></i>&nbsp; Edit Files</button></a>
									
									</h1>
								</div>
							</div>
							<?php							  
							$userprofile = $mydb->qry("select usermaster.id,name,aadhar,pan from usermaster,rolemaster where usermaster.role_id=rolemaster.id and usermaster.id=".$_SESSION['emp_id']);
							?>

                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                        	<tr>
                                            <td>Name</td>
											<td><?php echo $userprofile[0]['name'];?></td>
											</tr>
											
											<tr>
											<td>Aadhar Card</td>
											<td>
											<?php
											if ($userprofile[0]['aadhar']!='') {
											?>
											<img src="uploads/aadhar/<?php echo $userprofile[0]['aadhar'];?>" width="150">
											<?php }else{?>
											<img src="uploads/noimage.png" width="100">
											<?php } ?>
											</td>
											</tr>
                                       <tr>
											<td>Pan Card</td>
											<td>
											<?php
											if ($userprofile[0]['pan']!='') {?>
											<img src="uploads/pan/<?php echo $userprofile[0]['pan'];?>" width="150">
											<?php }else{?>
											<img src="uploads/noimage.png" width="100">
											<?php } ?>
											</td>
											
											</tr>
                                    <tbody>
                                        
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>											
	
	
											
<?php } ?>											
											
											
	</div>
	</div>										
    </div><!-- /#right-panel -->


   
   <?php include "include/script_files.php";?>

</body>

</html>
