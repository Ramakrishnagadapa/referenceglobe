<?php

session_start();
 
 unset($_SESSION['emp_id']);
 unset($_SESSION['emp_name']);
 unset($_SESSION['emp_role']);
 

 
  session_destroy();
 header("Location: login.php");
 ?>
 
 