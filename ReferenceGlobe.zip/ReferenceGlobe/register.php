<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ReferenceGlobe</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>


<?php

if($_POST){

extract($_POST);
include_once ('config/dbclass.php');
$mydb = new dbc();

date_default_timezone_set('Asia/Kolkata');
$todate = date('Y-m-d');

$mydb->qry("INSERT IGNORE INTO   usermaster (role_id,name,mobile,email,pwd,address,gender,dob,entrytime,approved) VALUES (3,'$name','$mobile','$email','$pwd','$address','$gender','$dob','$currentdate',0);");


header('location:register.php?success=1');
 


}

?>

<body class="bg-white">


    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                    <a href="index.php">
                        <img class="align-content" src="assets/img/logo.png" alt="" >
                    </a>
                </div>
                <div class="login-form">
				
				<?php if(isset($_GET['success'])==1){?>
				
				<b style="color:#FFFFFF">Your details submitted successfully and at pending status. Please wait for admin approval</b><br><br>
				<a href="login.php" class="btn btn-sm btn-info" style="width:200px">Go to Login Page</a>
				
				<?php }else{ ?>
                    <form name="form1" action="" method="post">
					 <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter Full Name" required>
                        </div>
						 <div class="form-group">
                            <label>Mobile</label>
                            <input type="text" name="mobile" class="form-control" placeholder="Enter Mobile" required>
                        </div>
						 <div class="form-group">
                            <label>Email</label>
                            <input type="text" name="email" class="form-control" placeholder="Enter Email ID" required>
                        </div>
						 <div class="form-group">
                            <label>Password</label>
                            <input type="text" name="pwd" class="form-control" placeholder="Enter Password" required>
                        </div>
						 <div class="form-group">
                            <label>Gender</label>
                            <select class="form-control" name="gender" required>
																<option value="">Select Gender</option>
																<option value="Male" >Male</option>
																<option value="Female">Female</option>
																</select>
                        </div>
						 <div class="form-group">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" class="form-control" placeholder="Enter Address" required>
                        </div>
                        <div class="form-group">
                            <label>Email address</label>
                            <input type="text" name="address" class="form-control" placeholder="Enter Address" required>
                        </div>
                            
                             <div class="checkbox">
                                    
									 <button type="submit" name="submit" class="btn btn-primary btn-flat m-b-30 m-t-30">Submit</button>
                               
                           
                                </div><br>
								<p style="text-align:center"><a href="login.php">Already had an account?</a></p>
                                
                                
                    </form>
					<?php } ?>
                </div>
            </div>
        </div>
    </div>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
