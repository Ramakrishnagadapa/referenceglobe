<?php session_start();  if(!isset($_SESSION['emp_id'])) { echo "<script>"; echo "location.href='login.php'"; echo "</script>"; }?>
<!doctype html>

<html class="no-js" lang="en">

<?php include "include/head.php";?>
<?php include "include/left_panel.php";?>


<script>
function showfarmerdata(str) {
  
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("searchfarmer").innerHTML=this.responseText;
      document.getElementById("searchfarmer").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","include/emp_search.php?query="+str,true);
  xmlhttp.send();
}
</script>

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include "include/header_top.php";?>
		<!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Employee Search</h1>
                    </div>
                </div>
            </div>
            
        </div>

 <div class="content mt-3">
            <div class="animated fadeIn">
			
			 <div class="col-lg-12">
                        <div class="card">
                            <div class="input-group">

  <input class="form-control mr-sm-2" type="text" onFocus="this.value=''" placeholder="Search Employee Name here..." aria-label="Search" onKeyUp="showfarmerdata(this.value)">
</div>
			</div>
			</div>
      <div class="col-lg-12">   
		 <div id="searchfarmer" style="background:#FFFFCC"></div>   
	</div>	

        </div> <!-- .content -->
    </div><!-- /#right-panel -->

</div>
   
   <?php include "include/script_files.php";?>

</body>

</html>
