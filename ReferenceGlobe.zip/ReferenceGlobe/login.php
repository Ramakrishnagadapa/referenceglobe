<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ReferenceGlobe</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>


<?php

if($_POST){

extract($_POST);
include_once ('config/dbclass.php');
$mydb = new dbc();

$qgetuser = $mydb->qry("select usermaster.id,name,mobile,email,code from usermaster,rolemaster where usermaster.role_id=rolemaster.id and email='".$email."' and pwd='".$pwd."' and approved=1");
if($qgetuser->num_rows=='0'){

header('location:login.php?error=1');
 
}else{
session_start();
$_SESSION['emp_id']=$qgetuser[0]['id'];
$_SESSION['emp_name']=$qgetuser[0]['name'];
$_SESSION['emp_email'] = $qgetuser[0]['email'];
$_SESSION['emp_role'] = $qgetuser[0]['code'];
 header('location:index.php');

}

}

?>

<body class="bg-white">


    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                    <a href="index.php">
                        <img class="align-content" src="assets/img/logo.png" alt="" >
                    </a>
                </div>
                <div class="login-form">
                    <form name="form1" action="" method="post">
                        <div class="form-group">
                            <label>Email address</label>
                            <input type="text" name="email" class="form-control" placeholder="Enter Email ID" required>
                        </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="pwd" class="form-control" placeholder="Password" required>
                        </div>
                             <div class="checkbox">
                                    <label>
									 <button type="submit" name="submit" class="btn btn-primary btn-flat m-b-30 m-t-30">Sign in</button>
                               
                            </label>
                                    <label class="pull-right">
                               <a href="register.php"  class="btn btn-success btn-flat m-b-30 m-t-30 text-white">Register</a>
                            </label>

                                </div>
								
                                
                                
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
