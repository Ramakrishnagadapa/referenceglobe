<?php session_start();  if(!isset($_SESSION['emp_id'])) { echo "<script>"; echo "location.href='login.php'"; echo "</script>"; }?>
<!doctype html>

<html class="no-js" lang="en">

<?php include "include/head.php";?>
<?php include "include/left_panel.php";?>


<?php
  $farmerenq = $mydb->qry("SELECT count(*) as totalfarmer FROM farmer_enquiry,district_master,state_master WHERE district_master.state_id=state_master.id and state_master.id=farmer_enquiry.state_id and farmer_enquiry.district_id=district_master.id");
  

?>



    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include "include/header_top.php";?>
		<!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Hello, <?php echo $_SESSION['emp_name'];?></h1>
                    </div>
                </div>
            </div>
            
        </div>


            


        </div> <!-- .content -->
    </div><!-- /#right-panel -->


   
   <?php include "include/script_files.php";?>

</body>

</html>
