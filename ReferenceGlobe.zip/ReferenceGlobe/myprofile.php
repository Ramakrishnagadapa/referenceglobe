<?php session_start();  if(!isset($_SESSION['emp_id'])) { echo "<script>"; echo "location.href='../index.php'"; echo "</script>"; }?>
<!doctype html>

<html class="no-js" lang="en">

<?php include "include/head.php";?>
<?php include "include/left_panel.php";?>


	


    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include "include/header_top.php";?>
		<!-- /header -->
        <!-- Header-->

 <div class="content mt-3">
            <div class="animated fadeIn">
				
<?php if( $_GET['action']=='edit' ){

 if($_POST['submit'] == "edit"){
						extract($_POST);
		

date_default_timezone_set('Asia/Kolkata');
$todate = date('Y-m-d');

if($_FILES["profilepic"]["name"]!=''){		
$target_path = "uploads/userpic/";
$extension = pathinfo($_FILES["profilepic"]["name"], PATHINFO_EXTENSION);
$newfilename=time().".".$extension;
$president_photo = $target_path.$newfilename;
move_uploaded_file($_FILES['profilepic']['tmp_name'], $president_photo);

$job_image = $newfilename;	
$updatephotos = ",profilepic='$newfilename'";

}

if($_FILES["usersignature"]["name"]!=''){		
$target_path = "uploads/signature/";
$extension = pathinfo($_FILES["usersignature"]["name"], PATHINFO_EXTENSION);
$newfilename=time().".".$extension;
$president_photo = $target_path.$newfilename;
move_uploaded_file($_FILES['usersignature']['tmp_name'], $president_photo);

$job_image = $newfilename;	
$signaturephotos = ",usersignature='$newfilename'";

}


					
						$mydb->qry("update   usermaster set name='$name',mobile='$mobile',email='$email',updatetime='$todate' $updatephotos $signaturephotos where id=".$_SESSION['emp_id']."");
						
						 
						echo "<script>";
						 echo "location.href='myprofile.php'";
						echo "</script>";
						}
						
						$getdata = $mydb->qry("select * from   usermaster where id=".$_SESSION['emp_id']);
						
				
					
?>		 
        <div class="col-lg-12">
		<form  method="post"  action="" enctype="multipart/form-data" name="form1">
		<input type="hidden" name="MAX_FILE_SIZE" value="300000000000" />
                                                <div class="card">
                                                    <div class="card-header">
                                                        <strong>Edit My Profile</strong>
                                                    </div>
                                                    <div class="card-body card-block">
													
                                                            
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Name</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="name" name="name"  class="form-control" value="<?php echo $getdata[0]['name'];?>" required></div>
                                                            </div>
															
                                                            
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Mobile</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="mobile" name="mobile"  class="form-control" value="<?php echo $getdata[0]['mobile'];?>" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Email</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="email" name="email"  class="form-control" value="<?php echo $getdata[0]['email'];?>" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Gender</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="gender" name="gender"  class="form-control" value="<?php echo $getdata[0]['gender'];?>" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">D.O.B.</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="dob" name="dob"  class="form-control" value="<?php echo $getdata[0]['dob'];?>" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Address</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="address" name="address"  class="form-control" value="<?php echo $getdata[0]['address'];?>" required></div>
                                                            </div>
															
															<div class="row form-group">
                                                                <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Profile Image</label></div>
                                                                <div class="col-12 col-md-9"><input type="file" id="profilepic" name="profilepic"  class="form-control" >
																</div>
                                                            </div>
															<div class="row form-group">
                                                                <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Signature</label></div>
                                                                <div class="col-12 col-md-9"><input type="file" id="usersignature" name="usersignature"  class="form-control" >
																</div>
                                                            </div>
                                                       
                                                    </div>
                                                    <div class="card-footer">
                                                        <button type="submit" name="submit" value="edit" class="btn btn-primary btn-sm float-right">
                                                            <i class="fa fa-dot-circle-o"></i> Update
                                                        </button>
                                                        
                                                    </div>
                                                </div>
                                                
                                                
                   </form>                             
                                            </div> <!-- .content -->
											
<?php }else{?>											
<div class="col-lg-12">
                        <div class="card">
                            <div class="page-header float-left">
								<div class="page-title">
									<h1>My Profile
									<a href="myprofile.php?action=edit"><button style="float:right" type="button" class="btn btn-success"><i class="fa fa-edit"></i>&nbsp; Edit Profile</button></a>
									
									</h1>
								</div>
							</div>
							<?php							  
							$userprofile = $mydb->qry("select usermaster.id,name,mobile,email,roleName,address,gender,dob,profilepic,usersignature from usermaster,rolemaster where usermaster.role_id=rolemaster.id and usermaster.id=".$_SESSION['emp_id']);
							?>

                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                        	<tr>
                                            <td>Name</td>
											<td><?php echo $userprofile[0]['name'];?></td>
											</tr>
											<tr>
                                            <td>Role</td>
											<td style="font-size:18px; color:#0033FF; font-weight:bold"><?php echo $userprofile[0]['roleName'];?></td>
											</tr>
											<tr>
											<td>Mobile</td>
											<td><?php echo $userprofile[0]['mobile'];?></td>
											</tr>
											<tr>
                                            <td>Email</td>
											<td><?php echo $userprofile[0]['email'];?></td>
											</tr>
											<tr>
                                            <td>Address</td>
											<td><?php echo $userprofile[0]['address'];?></td>
											</tr>
											<tr>
											<td>Gender</td>
											<td><?php echo $userprofile[0]['gender'];?></td>
											</tr>
											<tr>
											<td>Date of Birth</td>
											<td><?php echo $userprofile[0]['dob'];?></td>
											</tr>
											<tr>
											<td>Profile Pic</td>
											<td>
											<?php
											if ($userprofile[0]['profilepic']!='') {
											?>
											<img src="uploads/userpic/<?php echo $userprofile[0]['profilepic'];?>" width="150">
											<?php }else{?>
											<img src="uploads/noimage.png" width="100">
											<?php } ?>
											</td>
											
											</tr>
                                       <tr>
											<td>Singature</td>
											<td>
											<?php
											if ($userprofile[0]['usersignature']!='') {?>
											<img src="uploads/signature/<?php echo $userprofile[0]['usersignature'];?>" width="150">
											<?php }else{?>
											<img src="uploads/noimage.png" width="100">
											<?php } ?>
											</td>
											
											</tr>
                                    <tbody>
                                        
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>											
	
<script type="text/javascript">
function del_record(delid){
  
 	 if (confirm('Are you sure you want to delete this record?')) {
       document.location.href='advertisement.php?action=delete&id='+delid;
	} else {
		// Do nothing!
	}
}
</script>	
											
<?php } ?>											
											
											
	</div>
	</div>										
    </div><!-- /#right-panel -->


   
   <?php include "include/script_files.php";?>

</body>

</html>
