<?php session_start();  if(!isset($_SESSION['emp_id'])) { echo "<script>"; echo "location.href='../index.php'"; echo "</script>"; }?>
<!doctype html>

<html class="no-js" lang="en">

<?php include "include/head.php";?>
<?php include "include/left_panel.php";?>
<style>
.pagination{display:inline-block;padding-left:0;margin:20px 0;border-radius:4px}.pagination>li{display:inline}.pagination>li>a,.pagination>li>span{position:relative;float:left;padding:6px 12px;margin-left:-1px;line-height:1.42857143;color:#337ab7;text-decoration:none;background-color:#fff;border:1px solid #ddd}.pagination>li:first-child>a,.pagination>li:first-child>span{margin-left:0;border-top-left-radius:4px;border-bottom-left-radius:4px}.pagination>li:last-child>a,.pagination>li:last-child>span{border-top-right-radius:4px;border-bottom-right-radius:4px}.pagination>li>a:focus,.pagination>li>a:hover,.pagination>li>span:focus,.pagination>li>span:hover{z-index:2;color:#23527c;background-color:#eee;border-color:#ddd}.pagination>.active>a,.pagination>.active>a:focus,.pagination>.active>a:hover,.pagination>.active>span,.pagination>.active>span:focus,.pagination>.active>span:hover{z-index:3;color:#fff;cursor:default;background-color:#337ab7;border-color:#337ab7}.pagination>.disabled>a,.pagination>.disabled>a:focus,.pagination>.disabled>a:hover,.pagination>.disabled>span,.pagination>.disabled>span:focus,.pagination>.disabled>span:hover{color:#777;cursor:not-allowed;background-color:#fff;border-color:#ddd}.pagination-lg>li>a,.pagination-lg>li>span{padding:10px 16px;font-size:18px;line-height:1.3333333}.pagination-lg>li:first-child>a,.pagination-lg>li:first-child>span{border-top-left-radius:6px;border-bottom-left-radius:6px}.pagination-lg>li:last-child>a,.pagination-lg>li:last-child>span{border-top-right-radius:6px;border-bottom-right-radius:6px}.pagination-sm>li>a,.pagination-sm>li>span{padding:5px 10px;font-size:12px;line-height:1.5}.pagination-sm>li:first-child>a,.pagination-sm>li:first-child>span{border-top-left-radius:3px;border-bottom-left-radius:3px}.pagination-sm>li:last-child>a,.pagination-sm>li:last-child>span{border-top-right-radius:3px;border-bottom-right-radius:3px}.pager{padding-left:0;margin:20px 0;text-align:center;list-style:none}.pager li{display:inline}.pager li>a,.pager li>span{display:inline-block;padding:5px 14px;background-color:#fff;border:1px solid #ddd;border-radius:15px}.pager li>a:focus,.pager li>a:hover{text-decoration:none;background-color:#eee}.pager .next>a,.pager .next>span{float:right}.pager .previous>a,.pager .previous>span{float:left}.pager .disabled>a,.pager .disabled>a:focus,.pager .disabled>a:hover,.pager .disabled>span{color:#777;cursor:not-allowed;background-color:#fff}.label{display:inline;padding:.2em .6em .3em;font-size:75%;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25em}a.label:focus,a.label:hover{color:#fff;text-decoration:none;cursor:pointer}
</style>

	


    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include "include/header_top.php";?>
		<!-- /header -->
        <!-- Header-->

 <div class="content mt-3">
            <div class="animated fadeIn">
				
										
<div class="col-lg-12">
                        <div class="card">
                            <div class="page-header float-left">
								<div class="page-title">
									<h1>Employe List
									
									</h1>
								</div>
							</div>
							<?php		
							
							if (isset($_GET['pageno'])) {
									$pageno = $_GET['pageno'];
								} else {
									$pageno = 1;
								}
								$no_of_records_per_page = 10;
								$offset = ($pageno-1) * $no_of_records_per_page;
		
							  
							$userlist = $mydb->qry("select * from   employee_info LIMIT $offset, $no_of_records_per_page");
							
							$totalemp = $mydb->qry("select * from   employee_info");
							$total_pages = ceil(count($totalemp) / $no_of_records_per_page);
							?>

                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Sno</th>
											<th>Name</th>
                                            <th>Designation</th>
                                            <th>dob</th>
											<th>doj</th>
											<th>BGroup</th>
											<th>Mobile</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                  <?php for($i=0;$i<count($userlist);$i++){?>
                                        <tr>
                                            <td><?php echo $i+1;?></td>
											<td><?php echo $userlist[$i]['emp_name'];?></td>
                                            <td><?php echo $userlist[$i]['designation'];?></td>
											<td><?php echo $userlist[$i]['dob'];?></td>
                                            <td><?php echo $userlist[$i]['doj'];?></td>
											<td><?php echo $userlist[$i]['blood_group'];?></td>
											<td><?php echo $userlist[$i]['mobile'];?></td>
                                        </tr>
                                    <?php } ?>        
                                       
                                    </tbody>
                                </table>
								<?php /*?><ul class="pagination">
								<?php for($i=0;$i<$total_pages;$i++){?>
								<li><a href="?pageno=<?php echo $i+1;?>"><?php echo $i+1;?></a></li>
								<?php } ?>
							   </ul><?php */?>
								<ul class="pagination">
								<li><a href="?pageno=1"><< First</a></li>
								<li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
									<a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>"> < Prev</a>
								</li>
								<li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
									<a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next ></a>
								</li>
								<li><a href="?pageno=<?php echo $total_pages; ?>">Last >></a></li>
							</ul>
                            </div>
                        </div>
                    </div>											
	
	
											
										
											
											
	</div>
	</div>										
    </div><!-- /#right-panel -->


   
   <?php include "include/script_files.php";?>

</body>

</html>
