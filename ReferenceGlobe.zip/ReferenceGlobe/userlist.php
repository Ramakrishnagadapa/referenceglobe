<?php session_start();  if(!isset($_SESSION['emp_id'])) { echo "<script>"; echo "location.href='../index.php'"; echo "</script>"; }?>
<!doctype html>

<html class="no-js" lang="en">

<?php include "include/head.php";?>
<?php include "include/left_panel.php";?>


	


    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include "include/header_top.php";?>
		<!-- /header -->
        <!-- Header-->

        <!--<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Party Master</h1>
                    </div>
                </div>
            </div>
            
        </div>-->
 <div class="content mt-3">
            <div class="animated fadeIn">
				
<?php if($_GET['action']=='add' || $_GET['action']=='edit' ){

if($_POST['submit'] == "add")
{
extract($_POST);

date_default_timezone_set('Asia/Kolkata');
$currentdate = date('Y-m-d');
						
$mydb->qry("INSERT IGNORE INTO   usermaster (role_id,name,mobile,email,pwd,address,gender,dob,entrytime,approved,approved_by) VALUES (3,'$name','$mobile','$email','$pwd','$address','$gender','$dob','$currentdate',1,".$_SESSION['emp_id'].");");

$insertid = $mydb->id();
						
$target_path = "uploads/userpic/";
$extension = pathinfo($_FILES["profilepic"]["name"], PATHINFO_EXTENSION);
$newfilename=time().".".$extension;
$job_photo = $target_path.$newfilename;
move_uploaded_file($_FILES['profilepic']['tmp_name'], $job_photo);

$presidentimg = $newfilename;	

$mydb->qry("update usermaster set profilepic='$profilepic' where id=".$insertid."");						

						
						 
						echo "<script>";
						echo "location.href='userlist.php'";
						echo "</script>";
						
}else if($_POST['submit'] == "edit"){
						extract($_POST);
		

date_default_timezone_set('Asia/Kolkata');
$todate = date('Y-m-d');

if($_FILES["ad_image"]["name"]!=''){		
$target_path = "../flt-posit/";
$extension = pathinfo($_FILES["profilepic"]["name"], PATHINFO_EXTENSION);
$newfilename=time().".".$extension;
$president_photo = $target_path.$newfilename;
move_uploaded_file($_FILES['profilepic']['tmp_name'], $president_photo);

$job_image = $newfilename;	
$updatephotos = ",ad_image='$newfilename'";

}


					
						$mydb->qry("update   usermaster set name='$name',mobile='$mobile',email='$email',pwd='$pwd',address='$address',gender='$gender',dob='$dob',updatetime='$todate',approved='$approvestatus',approved_by=".$_SESSION['emp_id']." $updatephotos where id=".$_GET['id']."");
						
						 
						echo "<script>";
						 echo "location.href='userlist.php'";
						echo "</script>";
						}
						
						$getdata = $mydb->qry("select * from   usermaster where id=".$_GET['id']);
						
				
					
?>		 
        <div class="col-lg-12">
		<form  method="post"  action="" enctype="multipart/form-data" name="form1">
		<input type="hidden" name="MAX_FILE_SIZE" value="300000000000" />
                                                <div class="card">
                                                    <div class="card-header">
                                                        <strong>Add User</strong>
                                                    </div>
                                                    <div class="card-body card-block">
													
                                                            
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Name</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="name" name="name"  class="form-control" value="<?php echo $getdata[0]['name'];?>" placeholder="Enter User Name" required></div>
                                                            </div>
															
                                                            
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Mobile</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="mobile" name="mobile"  class="form-control" value="<?php echo $getdata[0]['mobile'];?>" placeholder="Enter Mobile" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Email</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="email" name="email"  class="form-control" value="<?php echo $getdata[0]['email'];?>" placeholder="Enter Email" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Password</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="pwd" name="pwd"  class="form-control" value="<?php echo $getdata[0]['pwd'];?>" placeholder="Enter Password" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Gender</label></div>
                                                                <div class="col-12 col-md-9">
																<select class="form-control" name="gender" required>
																<option value="">Select Gender</option>
																<option value="Male" <?php if($getdata[0]['gender']=='Male'){?> selected="selected" <?php } ?>>Male</option>
																<option value="Female" <?php if($getdata[0]['gender']=='Female'){?> selected="selected" <?php } ?>>Female</option>
																</select>
																</div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">D.O.B.</label></div>
                                                                <div class="col-12 col-md-9"><input type="date" id="dob" name="dob"  class="form-control" value="<?php echo $getdata[0]['dob'];?>" placeholder="Enter Date of Birth" required></div>
                                                            </div>
															<div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Address</label></div>
                                                                <div class="col-12 col-md-9"><input type="text" id="address" name="address"  class="form-control" value="<?php echo $getdata[0]['address'];?>" placeholder="Enter Full Address" required></div>
                                                            </div>
															
															<div class="row form-group">
                                                                <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Profile Image</label></div>
                                                                <div class="col-12 col-md-9"><input type="file" id="profilepic" name="profilepic"  class="form-control" >
																</div>
                                                            </div>
															<div class="row form-group">
                                                                <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Signature</label></div>
                                                                <div class="col-12 col-md-9"><input type="file" id="usersignature" name="usersignature"  class="form-control" >
																</div>
                                                            </div>
                                                       
													   <div class="row form-group">
                                                               <div class="col col-md-3"><label for="hf-password" class=" form-control-label">Status</label></div>
                                                                <div class="col-12 col-md-9">
																<select class="form-control" name="approvestatus" required>
																<option value="0" <?php if($getdata[0]['approved']==0){?> selected="selected" <?php } ?>>Pending</option>
																<option value="1" <?php if($getdata[0]['approved']==1){?> selected="selected" <?php } ?>>Approved</option>
																<option value="2" <?php if($getdata[0]['approved']==2){?> selected="selected" <?php } ?>>Deleted</option>
																</select>
																</div>
                                                            </div>
                                                    </div>
                                                    <div class="card-footer">
                                                        <button type="submit" name="submit" value="<?php echo $_GET['action'];?>" class="btn btn-primary btn-sm">
                                                            <i class="fa fa-dot-circle-o"></i> Submit
                                                        </button>
                                                        <button type="reset" class="btn btn-danger btn-sm">
                                                            <i class="fa fa-ban"></i> Reset
                                                        </button>
                                                    </div>
                                                </div>
                                                
                                                
                   </form>                             
                                            </div> <!-- .content -->
											
<?php }else if($_GET['action']=='delete' ){
						
						$mydb->qry("update usermaster set approved=2 where id=".$_GET['id']."");
						
						 
						echo "<script>";
						 echo "location.href='userlist.php'";
						echo "</script>";
						   
						 
 }else{?>											
<div class="col-lg-12">
                        <div class="card">
                            <div class="page-header float-left">
								<div class="page-title">
									<h1>User List
									&nbsp;
									<a href="userlist.php?action=add"><button style="float:right" type="button" class="btn btn-success"><i class="fa fa-plus"></i>&nbsp; Add User</button></a>
									
									</h1>
								</div>
							</div>
							<?php							  
							$userlist = $mydb->qry("select * from   usermaster where role_id=3 order by id desc");
							?>

                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Sno</th>
											<th>UserName</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
											<th>Gender</th>
											<th>Status</th>
											<th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                  <?php for($i=0;$i<count($userlist);$i++){?>
                                        <tr>
                                            <td><?php echo $i+1;?></td>
											<td><?php echo $userlist[$i]['name'];?></td>
                                            <td><?php echo $userlist[$i]['email'];?></td>
											<td><?php echo $userlist[$i]['mobile'];?></td>
                                            <td><?php echo $userlist[$i]['gender'];?></td>
											<td><?php
											 if($userlist[$i]['approved']==0){ 
											 echo '<b style="color:#0033CC">Pending</b>'; 
											 }else if($userlist[$i]['approved']==01){ 
											 echo '<b style="color:#006633">Approved</b>'; 
											 }else{ 
											 echo '<b style="color:#ff0000">Deleted</b>';  
											 };?></td>
											<td>
											<?php if($_SESSION['emp_role']=='super'){?>
											<a href="userlist.php?action=edit&id=<?php echo $userlist[$i]['id'];?>"><i class="menu-icon fa fa-edit"></i></a>
											 <?php } ?>
											 &nbsp; <a href="" onClick="del_record(<?php echo $userlist[$i]['id'];?>)"><i class="menu-icon fa fa-trash"></i></a>
											
											 </td>
                                        </tr>
                                    <?php } ?>        
                                       
                                    </tbody>
                                </table>
								<a  class="btn btn-sm btn-primary" onClick="showuserdata()">Get Data as JSON</a>
								<div class="col-lg-12">   
									 <div id="userdata" style="background:#FFFFCC"></div>   
								</div>
                            </div>
                        </div>
                    </div>											
	
<script type="text/javascript">
function del_record(delid){
  
 	 if (confirm('Are you sure you want to delete this record?')) {
       document.location.href='userlist.php?action=delete&id='+delid;
	} else {
		// Do nothing!
	}
}
</script>	

<script>
function showuserdata() {
  
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
	console.log(this.responseText);
      document.getElementById("userdata").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","include/getuserdata.php",true);
  xmlhttp.send();
}
</script>
											
<?php } ?>											
											
											
	</div>
	</div>										
    </div><!-- /#right-panel -->


   
   <?php include "include/script_files.php";?>

</body>

</html>
