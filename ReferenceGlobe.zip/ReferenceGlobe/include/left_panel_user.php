<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="../images/farmerlogo.png" alt="Logo" width="100"></a>
                <a class="navbar-brand hidden" href="./"><img src="../images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
					<li class="active">
                        <a href="order_now.php"> <i class="menu-icon fa fa-tags"></i>Order Now </a>
                    </li>
					<li class="active">
                        <a href="emp_commission_info.php"> <i class="menu-icon fa fa-tags"></i>Emp Commission </a>
                    </li>
					<!--<li class="active">
                        <a href="farmer_master.php"> <i class="menu-icon fa fa-users"></i>Farmers </a>
                    </li>
					<li class="active">
                        <a href="farmer_enquiry_list.php"> <i class="menu-icon fa fa-users"></i>Farmers Enquiry </a>
                    </li>
					<li class="active">
                        <a href="create_order.php"> <i class="menu-icon fa fa-shopping-cart"></i>Orders </a>
                    </li>-->
					

                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>