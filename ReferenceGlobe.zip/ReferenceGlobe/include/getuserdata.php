<?php

include "../config/dbclass.php";
$mydb = new dbc();

$res = $mydb->qry("select * from usermaster");


echo json_encode($res);

?>