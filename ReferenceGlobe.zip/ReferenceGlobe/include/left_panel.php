<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="assets/img/logo.png" alt="Logo" width="100"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
			
			<?php if($_SESSION['emp_role']=='super'){?>
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
					<li class="active">
                        <a href="myprofile.php"> <i class="menu-icon fa fa-table"></i>My Profile</a>
                    </li>
					<li class="active">
                        <a href="userlist.php"> <i class="menu-icon fa fa-table"></i>Users List </a>
                    </li>
					
					<li class="active">
                        <a href="employeelist.php"> <i class="menu-icon fa fa-table"></i>Employee List </a>
                    </li>
                    <li class="active">
                        <a href="searchemployee.php"> <i class="menu-icon fa fa-table"></i>Employee Search </a>
                    </li>
					<li class="active">
                        <a href="uploadidentity.php"> <i class="menu-icon fa fa-table"></i>Upload Identity Files</a>
                    </li>
             <?php }else if($_SESSION['emp_role']=='admin'){?>
			 
			 <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
					<li class="active">
                        <a href="myprofile.php"> <i class="menu-icon fa fa-table"></i>My Profile</a>
                    </li>
					<li class="active">
                        <a href="userlist.php"> <i class="menu-icon fa fa-table"></i>Users List </a>
                    </li>
					<li class="active">
                        <a href="uploadidentity.php"> <i class="menu-icon fa fa-table"></i>Upload Identity Files</a>
                    </li>
			 <?php }else{?>
			 <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
					<li class="active">
                        <a href="myprofile.php"> <i class="menu-icon fa fa-table"></i>My Profile</a>
                    </li>
					<li class="active">
                        <a href="uploadidentity.php"> <i class="menu-icon fa fa-table"></i>Upload Identity Files</a>
                    </li>
			 
			 
			 <?php }?>       
                    

                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>