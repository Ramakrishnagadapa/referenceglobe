<?php

//CREDENTIALS FOR DB

$con = mysqli_connect("localhost","root","","referenceglobe");

//CREATE QUERY TO DB AND PUT RECEIVED DATA INTO ASSOCIATIVE ARRAY
if (isset($_REQUEST['query'])) {
    $query = $_REQUEST['query'];

$searchdata='';	
if(strlen($query)>0){	  
	   $q="SELECT * FROM employee_info WHERE emp_name LIKE '%{$query}%'";
	   

$query = mysqli_query($con,$q);

$string = '<table  class="table table-bordered table-hover " style="font:12px Verdana, Arial, Helvetica, sans-serif">';


if (mysqli_num_rows($query)){
while($row = mysqli_fetch_array($query)){

$string .= "<tr>";
$string .= "<td>".$row['emp_name']." ";
$string .= $row['designation']."</a></td>";
$string .= "</tr>";
}
$string .= "</table>";
}else{
$string = "No matches found!";
}

echo $string;
}

}else{
echo '';
}
?>