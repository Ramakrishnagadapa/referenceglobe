-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2021 at 07:01 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `referenceglobe`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee_info`
--

CREATE TABLE `employee_info` (
  `id` int(11) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `doj` date NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_info`
--

INSERT INTO `employee_info` (`id`, `emp_name`, `designation`, `dob`, `doj`, `blood_group`, `mobile`, `email`, `address`) VALUES
(1, 'Aleshia', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01944-369967', 'atomkiewicz@hotmail.com', '14 Taylor St'),
(2, 'Evan', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01714-737668', 'evan.zigomalas@gmail.com', '5 Binney St'),
(3, 'France', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01935-821636', 'france.andrade@hotmail.com', '8 Moor Place'),
(4, 'Ulysses', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01302-601380', 'ulysses@hotmail.com', '505 Exeter Rd'),
(5, 'Tyisha', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01290-367248', 'tyisha.veness@hotmail.com', '5396 Forth Street'),
(6, 'Eric', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01545-817375', 'erampy@rampy.co.uk', '9472 Lind St'),
(7, 'Marg', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01362-620532', 'marg@hotmail.com', '7457 Cowl St #70'),
(8, 'Laquita', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01590-982428', 'laquita@yahoo.com', '20 Gloucester Pl #96'),
(9, 'Lura', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01340-713951', 'lura@hotmail.com', '929 Augustine St'),
(10, 'Yuette', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01933-512513', 'yuette.klapec@klapec.co.uk', '45 Bradfield St #166'),
(11, 'Fernanda', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01687-879391', 'fernanda@writer.co.uk', '620 Northampton St'),
(12, 'Charlesetta', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01517-624517', 'charlesetta_erm@gmail.com', '5 Hygeia St'),
(13, 'Corrinne', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01642-322954', 'corrinne_jaret@gmail.com', '2150 Morley St'),
(14, 'Niesha', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01342-793603', 'niesha.bruch@yahoo.com', '24 Bolton St'),
(15, 'Rueben', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01956-535511', 'rueben_gastellum@gastellum.co.uk', '4 Forrest St'),
(16, 'Michell', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01672-496478', 'mthrossell@throssell.co.uk', '89 Noon St'),
(17, 'Edgar', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01666-638176', 'edgar.kanne@yahoo.com', '99 Guthrie St'),
(18, 'Dewitt', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01241-964675', 'dewitt.julio@hotmail.com', '7 Richmond St'),
(19, 'Charisse', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01207-428520', 'charisse_spinello@spinello.co.uk', '9165 Primrose St'),
(20, 'Mee', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01939-815208', 'mee.lapinski@yahoo.com', '9 Pengwern St'),
(21, 'Peter', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01859-648598', 'peter_gutierres@yahoo.com', '4410 Tarlton St'),
(22, 'Octavio', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01743-139456', 'octavio.salvadore@yahoo.com', '6949 Bourne St'),
(23, 'Martha', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01583-287367', 'mteplica@teplica.co.uk', '148 Rembrandt St'),
(24, 'Tamesha', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01280-786847', 'tveigel@veigel.co.uk', '2200 Nelson St #58'),
(25, 'Tess', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01848-116775', 'tess_sitra@hotmail.com', '61 Rossett St'),
(26, 'Leonard', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01604-718601', 'lkufner@kufner.co.uk', '41 Canning St'),
(27, 'Svetlana', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01509-121140', 'svetlana_tauras@tauras.co.uk', '8289 Cadogan St'),
(28, 'Pok', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01315-284286', 'pok@yahoo.com', '211 Hobart St'),
(29, 'Augustine', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01926-108010', 'augustine.growcock@growcock.co.uk', '114 Falkland St #8845'),
(30, 'Karma', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01307-667811', 'kquarto@gmail.com', '1 Birkett St'),
(31, 'Reed', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01292-297245', 'reed_weisinger@yahoo.com', '5147 Blackstone St'),
(32, 'German', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01366-210656', 'german@hotmail.com', '7 Shenstone St'),
(33, 'Milly', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01421-132652', 'milly@gmail.com', '129 Alexander Pope St'),
(34, 'Luis', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01405-648623', 'luis@hotmail.com', '2 Birchfield Rd'),
(35, 'Ciara', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01809-443217', 'ciara_cobbley@hotmail.com', '7523 Kempton Rd'),
(36, 'Alethea', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01351-868965', 'alethea@hotmail.com', '6305 Elstow St'),
(37, 'Margurite', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01640-661191', 'mloperfido@gmail.com', '218 Greenbank Drive'),
(38, 'Vernice', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01765-519419', 'vernice@yahoo.com', '8921 Forge St'),
(39, 'Vicente', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01286-258121', 'vicente_rawicki@hotmail.com', '3060 St Ambrose Grove #261'),
(40, 'Craig', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01818-980469', 'craig@hotmail.com', '8388 Bessemer St #5'),
(41, 'Jenise', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01572-193368', 'jenise.dulle@hotmail.com', '87 Pownall Sq'),
(42, 'Marylin', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01295-331807', 'marylin_cornelison@yahoo.com', '39 Wye St'),
(43, 'Marget', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01512-975244', 'mgunst@yahoo.com', '2732 Bostock St #1'),
(44, 'Annett', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01333-972244', 'abunselmeyer@hotmail.com', '5562 Fairfield St #847'),
(45, 'Kip', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01222-164469', 'kip.turziano@yahoo.com', '37 Meadow St'),
(46, 'Melina', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01245-559333', 'melina@gmail.com', '3 Nevison St'),
(47, 'Tina', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01493-245349', 'tclapham@gmail.com', '5662 William Moult St'),
(48, 'Luisa', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01334-807355', 'ldevereux@gmail.com', '3 North View #35'),
(49, 'Pedro', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01823-517315', 'paschoff@yahoo.com', '135 Opie St'),
(50, 'Carrol', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01415-364461', 'carrol_kunimitsu@yahoo.com', '1 Askew St'),
(51, 'Alba', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01231-806535', 'alba@gmail.com', '4 Burnall St'),
(52, 'Domonique', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01987-728730', 'domonique@hotmail.com', '95 Denton St'),
(53, 'Rory', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01442-700486', 'rory_neufville@neufville.co.uk', '5 Chadwick St #7'),
(54, 'Dustin', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01523-775781', 'dklingaman@gmail.com', '67 Micawber St'),
(55, 'Lyndia', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01789-132579', 'lyndia_moonshower@moonshower.co.uk', '43 Williamson St #7995'),
(56, 'Jules', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01814-878359', 'jules@yahoo.com', '5 Howe St'),
(57, 'Dong', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01639-518104', 'dkopczynski@kopczynski.co.uk', '7 Cheapside #9'),
(58, 'Justine', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01376-851958', 'justine_salta@yahoo.com', '85 Bridgewater St'),
(59, 'Chantay', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01245-146126', 'ckamens@hotmail.com', '763 Parkfield Rd'),
(60, 'Tequila', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01702-946496', 'tequila.chisum@chisum.co.uk', '662 Grove Park'),
(61, 'Maybelle', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01351-200904', 'mconsolazio@yahoo.com', '5410 Lawton St'),
(62, 'Margarett', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01903-424890', 'margarett@gmail.com', '3 August Rd'),
(63, 'Janessa', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01841-979075', 'jnoonon@yahoo.com', '476 Starkie St'),
(64, 'Sol', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01580-134516', 'sol@gmail.com', '6448 Tillard St'),
(65, 'Louann', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01488-872531', 'louann@gmail.com', '3055 Creswick St'),
(66, 'Lindsay', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01481-295251', 'lindsay_yadao@yadao.co.uk', '7 Jolliffe St'),
(67, 'Malika', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01705-208145', 'malika@gmail.com', '1175 Greig St'),
(68, 'Stefany', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01704-986828', 'stefany@hotmail.com', '636 Portland Place'),
(69, 'Abraham', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01695-305111', 'acratch@gmail.com', '41 Benedict St'),
(70, 'Giuseppe', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01866-845669', 'giuseppe@yahoo.com', '62 Margaret St'),
(71, 'Kiera', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01783-446052', 'kbassil@bassil.co.uk', '5152 Sophia St'),
(72, 'Wendell', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01752-386691', 'wendell_rubano@hotmail.com', '1 Back Canning St'),
(73, 'Stevie', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01411-169215', 'stevie_stifflemire@stifflemire.co.uk', '9 Gradwell St'),
(74, 'Yun', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01374-255198', 'yun_paletta@paletta.co.uk', '9205 Upper Hill St'),
(75, 'Brittani', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01970-890023', 'bthurm@yahoo.com', '9 Horatio St'),
(76, 'Billy', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01703-435212', 'billy.venus@yahoo.com', '61 Miriam St'),
(77, 'Brynn', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01345-625433', 'brynn@yahoo.com', '67 Pulford St'),
(78, 'Elroy', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01586-387018', 'epiehler@piehler.co.uk', '821 Pembroke Place'),
(79, 'Anisha', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01268-233798', 'ashulick@yahoo.com', '3 Alder St'),
(80, 'Bettina', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01340-622388', 'bettina.kham@kham.co.uk', '80 Morecambe St'),
(81, 'Velda', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01368-456268', 'velda_mancilla@mancilla.co.uk', '7866 Renshaw St #283'),
(82, 'Marta', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01631-454193', 'marta.brace@brace.co.uk', '658 Lake St'),
(83, 'Juan', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01728-150282', 'juan_vanwyhe@gmail.com', '5382 Redfern St'),
(84, 'Lelia', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01322-715065', 'lelia.filion@filion.co.uk', '45 Bidder St #38'),
(85, 'Una', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01308-356704', 'ufrankel@hotmail.com', '6766 Britton St #379'),
(86, 'Eva', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01961-802899', 'eva.joulwan@gmail.com', '7 Lear Rd'),
(87, 'Mammie', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01439-184366', 'mammie_dormanen@hotmail.com', '2577 Toxteth St #5'),
(88, 'Jeannetta', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01440-276155', 'jeannetta_coolidge@gmail.com', '761 Cockerell St #1'),
(89, 'Elbert', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01496-526674', 'edrawe@drawe.co.uk', '9 Cypress St'),
(90, 'Lenny', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01342-706893', 'lenny.gazzola@yahoo.com', '6 Romilly St'),
(91, 'Mira', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01381-836777', 'mira.alpheaus@yahoo.com', '51 St Anne St #12'),
(92, 'Cathern', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01266-671305', 'cathern.ungar@ungar.co.uk', '823 Idris St'),
(93, 'Malcom', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01937-120539', 'malcom.fleckles@gmail.com', '8764 Nickleby St #877'),
(94, 'Monroe', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01440-164945', 'mdamato@damato.co.uk', '5344 Bengel St #5'),
(95, 'Leota', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01414-780251', 'lfletchen@gmail.com', '8880 Great Howard St #7750'),
(96, 'Berry', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01929-400879', 'berry@gmail.com', '9 Oakleigh'),
(97, 'Meghan', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01650-129106', 'meghan@riherd.co.uk', '83 Denbigh St Bootle'),
(98, 'Mike', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01408-918612', 'mike_torner@torner.co.uk', '30 Aughton St'),
(99, 'Elsa', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01204-471598', 'elsa_delisle@gmail.com', '260 Saxon St'),
(100, 'Linwood', 'Production Employee', '1990-08-15', '2011-01-01', '0+', '01244-769346', 'linwood.rosenlof@yahoo.com', '3 Pyramid St');

-- --------------------------------------------------------

--
-- Table structure for table `rolemaster`
--

CREATE TABLE `rolemaster` (
  `id` int(11) NOT NULL,
  `roleName` varchar(20) NOT NULL,
  `code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rolemaster`
--

INSERT INTO `rolemaster` (`id`, `roleName`, `code`) VALUES
(1, 'Super Admin', 'super'),
(2, 'Admin', 'admin'),
(3, 'User', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

CREATE TABLE `usermaster` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pwd` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `profilepic` varchar(50) NOT NULL,
  `usersignature` varchar(50) NOT NULL,
  `aadhar` varchar(30) NOT NULL,
  `pan` varchar(30) NOT NULL,
  `entrytime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `approved` tinyint(4) NOT NULL DEFAULT '0',
  `approved_by` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usermaster`
--

INSERT INTO `usermaster` (`id`, `role_id`, `name`, `mobile`, `email`, `pwd`, `address`, `gender`, `dob`, `profilepic`, `usersignature`, `aadhar`, `pan`, `entrytime`, `updatetime`, `approved`, `approved_by`) VALUES
(1, 1, 'Super', '9999999999', 'superadmin@gmail.com', '1234', 'Kakinada', 'Male', '1991-12-03', '1639969153.jpg', '1639969201.jpg', '', '', '2021-12-19 12:09:27', '2021-12-20 00:00:00', 1, 1),
(3, 2, 'Admin', '9640864111', 'admin@gmail.com', '1234', '3-18,Main road', 'Female', '2021-12-20', '', '', '', '', '2021-12-20 00:00:00', '0000-00-00 00:00:00', 1, 1),
(4, 3, 'Suresh Kumar', '9999999999', 'suresh@gmail.com', '1234', 'Hyderabad', 'Male', '2005-06-16', '', '', '', '', '2021-12-20 00:00:00', '2021-12-20 00:00:00', 2, 1),
(5, 3, 'Gowtham', '999899898', 'gowtham@gmail.com', '1234', 'test', 'Male', '2021-12-15', '', '', '', '', '0000-00-00 00:00:00', '2021-12-20 00:00:00', 1, 1),
(6, 3, 'P VENKATESH', '989898989', 'venki@gmail.com', '1234', 'Vizag', 'Male', '2021-12-10', '', '', '', '', '0000-00-00 00:00:00', '2021-12-20 00:00:00', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee_info`
--
ALTER TABLE `employee_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rolemaster`
--
ALTER TABLE `rolemaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usermaster`
--
ALTER TABLE `usermaster`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee_info`
--
ALTER TABLE `employee_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `rolemaster`
--
ALTER TABLE `rolemaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `usermaster`
--
ALTER TABLE `usermaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
